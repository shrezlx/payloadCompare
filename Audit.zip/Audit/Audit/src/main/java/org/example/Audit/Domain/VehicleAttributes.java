package org.example.Audit.Domain;

import lombok.Data;

@Data
public abstract class VehicleAttributes {
    private String make;
    private String model;
    private String year;
    private String color;
    private int vehicleCount;
}
