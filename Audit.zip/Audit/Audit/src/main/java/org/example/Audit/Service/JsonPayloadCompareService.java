package org.example.Audit.Service;

import org.example.Audit.Domain.PersonDTO;

import java.util.List;

public interface JsonPayloadCompareService {
    boolean compareService(List<Object> objectList);
}
