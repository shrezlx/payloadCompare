package org.example.Audit.Domain;

import lombok.Data;

@Data
public class MotorCycle extends VehicleAttributes {
}
