package org.example.Audit.Service.Impl;


import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import lombok.extern.slf4j.Slf4j;
import org.example.Audit.Service.JsonPayloadCompareService;
import org.example.Audit.Utils.JsonArrayComparator;
import org.springframework.stereotype.Service;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@Slf4j
public class JsonPayloadCompareServiceImpl implements JsonPayloadCompareService {
    @Override
    public boolean compareService(List<Object> objectList) {
        Gson gson = new Gson();

        String jsonPerson1 = gson.toJson(objectList.get(0));
        String jsonPerson2 = gson.toJson(objectList.get(1));


        Type mapType = new TypeToken<Map<String, Object>>() {
        }.getType();
        Map<String, Object> firstMap = gson.fromJson(jsonPerson1, mapType);
        Map<String, Object> secondMap = gson.fromJson(jsonPerson2, mapType);
        MapDifference<String, Object> maps = Maps.difference(firstMap, secondMap);


        String json = gson.toJson(maps.entriesDiffering());
        Map map = gson.fromJson(json, Map.class);
        if (map.size() == 0) {
            System.out.println("Everything matches");
            return true;
        }

        Set<String> keySet = map.keySet();
        for (String key : keySet) {
            Map diffMap = (Map) map.get(key);


            String jsonString = gson.toJson(diffMap.get("left"));
            JsonElement jsonElement = JsonParser.parseString(jsonString);
            JsonArray jsonArrayLeft = jsonElement.getAsJsonArray();




            jsonString = gson.toJson(diffMap.get("right"));

            jsonElement = JsonParser.parseString(jsonString);
            JsonArray jsonArrayRight = jsonElement.getAsJsonArray();




            JsonArrayComparator jsonArrayComparator = new JsonArrayComparator();
            if (!jsonArrayComparator.compareJsonArray(jsonArrayLeft, jsonArrayRight)) {
                return false;
            }

        }
        return true;
    }
}
