package org.example.Audit.Domain;

import lombok.Data;

@Data
public class PhoneNumber {
    private String home;
    private String office;
    private String personal;

}
