package org.example.Audit.Controller;

import lombok.RequiredArgsConstructor;
import org.example.Audit.Domain.PersonDTO;
import org.example.Audit.Service.JsonPayloadCompareService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/compare")
@RestController
@RequiredArgsConstructor
public class CompareController {

    private final JsonPayloadCompareService jsonPayloadCompareService;

    @GetMapping("/get")
    public boolean getCompare(@RequestBody List<Object> objectList) {
        return jsonPayloadCompareService.compareService(objectList);
    }
}
