package org.example.Audit.Domain;

import lombok.Data;

import java.util.List;

@Data
public class PersonDTO {
    private String name;
    private int age;
    private List<PhoneNumber> phoneNumberList;
    private List<Vehicle> vehicleList;
}




