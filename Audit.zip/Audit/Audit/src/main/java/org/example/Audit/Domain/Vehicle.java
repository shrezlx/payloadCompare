package org.example.Audit.Domain;

import lombok.Data;

import java.util.List;

@Data
public class Vehicle {
    private List<Car> carList;
    private List<MotorCycle> motorCycleList;
    private List<Boat> boatList;
}
