package org.example.Audit.Utils;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Type;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
public class JsonArrayComparator {


    public boolean compareJsonArray(JsonArray jsonArrayLeft, JsonArray jsonArrayRight) {
        List<String> keyListLeft = new ArrayList<>();
        List<String> valueListLeft = new ArrayList<>();
        List<String> keyListRight = new ArrayList<>();
        List<String> valueListRight = new ArrayList<>();
        Gson gson = new Gson();
        List<JsonArray> jsonArrayLeftRecursive = new ArrayList<>();
        List<JsonArray> jsonArrayRightRecursive = new ArrayList<>();
        int leftCount = 0;
        int rightCount = 0;

        System.out.println(jsonArrayLeft);
        System.out.println(jsonArrayRight);
        System.out.println("\n\n");


        for (int i = 0; i < jsonArrayLeft.size(); i++) {
            /*Left Arrary*/
            try {
                Map mapLeft = gson.fromJson(jsonArrayLeft.get(i), Map.class);
                Set<String> keySet1 = mapLeft.keySet();
                for (Object key : keySet1) {
                    keyListLeft.add((String) key);
                    try {
                        valueListLeft.add((String) mapLeft.get(key));
                    } catch (ClassCastException exception) {
                        leftCount++;
                        JsonElement jsonElement = JsonParser.parseString(gson.toJson(mapLeft.get(key)));
                        jsonArrayLeftRecursive.add(jsonElement.getAsJsonArray());
                    }
                }
            } catch (Exception exception) {
                log.info("Continue");
            }


            /*Right Arrary*/
            try {
                Map mapRight = gson.fromJson(jsonArrayRight.get(i), Map.class);
                Set<String> keySet2 = mapRight.keySet();
                for (Object key : keySet2) {
                    keyListRight.add((String) key);
                    try {
                        valueListRight.add((String) mapRight.get(key));
                    } catch (ClassCastException exception) {
                        rightCount++;
                        JsonElement jsonElement = JsonParser.parseString(gson.toJson(mapRight.get(key)));
                        jsonArrayRightRecursive.add(jsonElement.getAsJsonArray());
                    }
                }
            } catch (Exception exception) {
                log.info("Continue");
            }

            Collections.sort(keyListLeft);
            Collections.sort(keyListRight);


            if (keyListLeft.size() == keyListRight.size()) {
              for(int j = 0;j<keyListLeft.size();j++){
                  System.out.println(keyListLeft.get(j));
                  System.out.println(keyListRight.get(j));
                  System.out.println();
                  if(!keyListLeft.get(j).equals(keyListRight.get(j))){
                      return false;
                  }
              }
            }else{
                return false;
            }

            }


        if (jsonArrayLeftRecursive.size() > 0 && jsonArrayRightRecursive.size() > 0) {
            for (int i = 0; i < jsonArrayLeftRecursive.size(); i++) {
                if (!compareJsonArray(jsonArrayLeftRecursive.get(i), jsonArrayRightRecursive.get(i))) {
                    return false;
                }
            }
        }

        if (leftCount > 0 && rightCount > 0) {
            try {
                Type ArrayType = new TypeToken<ArrayList<String>>() {
                }.getType();
                ArrayList<String> arrayLeftRecursive = gson.fromJson(jsonArrayLeftRecursive.get(0), ArrayType);
                Collections.sort(arrayLeftRecursive);
                valueListLeft = arrayLeftRecursive;

                ArrayList<String> arrayRightRecursive = gson.fromJson(jsonArrayRightRecursive.get(0), ArrayType);
                Collections.sort(arrayRightRecursive);
                valueListRight = arrayRightRecursive;
            } catch (Exception exception) {
                compareJsonArray(jsonArrayLeftRecursive.get(0), jsonArrayRightRecursive.get(0));
            }
        }


        Collections.sort(keyListLeft);
        Collections.sort(valueListLeft);
        Collections.sort(keyListRight);
        Collections.sort(valueListRight);


        if (keyListLeft.size() == keyListRight.size()) {
            List<Integer> resultKey = IntStream.range(0, valueListLeft.size())
                    .map(j -> keyListLeft.get(j).compareTo(keyListRight.get(j)))
                    .boxed().collect(Collectors.toList());


            List<String> finalValueListLeft = valueListLeft;
            List<String> finalValueListRight = valueListRight;
            List<Integer> resultValue = IntStream.range(0, valueListLeft.size())
                    .map(j -> finalValueListLeft.get(j).compareTo(finalValueListRight.get(j)))
                    .boxed().collect(Collectors.toList());
            System.out.println(resultKey);
            System.out.println();
            System.out.println(resultValue);
            System.out.println();

            for (Integer integer : resultKey) {
                if (!integer.equals(0)) {
                    return false;
                }
            }
            for (Integer integer : resultValue) {
                if (!integer.equals(0)) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }

    }

}

