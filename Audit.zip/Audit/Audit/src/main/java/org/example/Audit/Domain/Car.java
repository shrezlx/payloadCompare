package org.example.Audit.Domain;

import lombok.Data;

import java.util.List;

@Data
public class Car extends VehicleAttributes {
//    private List<String> good;
}
